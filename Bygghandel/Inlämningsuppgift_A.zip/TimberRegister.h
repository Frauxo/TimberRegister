//Emil Hallin
//DV1519 - Inl�mningsuppgift A
//2017-02-03

#ifndef TIMBERREGISTER_H
#define TIMBERREGISTER_H
#include "Timber.h"

using namespace std;

class TimberRegister
{
private:
	Timber** newTimber;
	int nrOfTimber;
	int timberRegisterCapacity ;

public:
	TimberRegister();
	TimberRegister(const TimberRegister &other);
	~TimberRegister();

	void addTimber(const string dimension, const int runningMetre, const float price);
	bool removeTimber(const string answer);
	string printTimber();
	string printTimberUnderRunningMetre(const int answer);
	void expand();
	void changeProperties(const string dimension, const int choice, const float change);
	float displayPrice() const;
	void saveToFile(const string filename);
	void loadFile(const string filename);
	

	TimberRegister& operator=(const TimberRegister &other);
};
#endif // !TIMBERREGISTER_H